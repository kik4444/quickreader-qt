# Quick Reader

Quick Reader is a program that enables its user to quickly read through text.
Quick Reader is free software released under GPL. The source code is available on GitLab.
You should have received a copy of the GNU General Public License along with this program. If not, see http://www.gnu.org/licenses/
This is my first piece of free open source software, so I hope it meets your expectations of quality and may it serve you well.

Demo Video:
![Sample Video](Assets/Demo.mp4)